# Jira OSLC Addon

An OSLC 2.0 adapter for **Jira Data Center 10.x**, implementing:

- **Service Provider Catalog** – exposes all Jira projects as OSLC service providers
- **OSLC Change Management** – maps Jira issues to `oslc_cm:ChangeRequest` resources
- **OSLC Query** – `oslc.where` / `oslc.select` / `oslc.paging` over Jira's JQL engine
- **Resource Linking** – store and display outgoing OSLC links on any Jira issue
- **Selection Dialog** – delegated UI for external tools to pick Jira issues
- **Hover Preview** – OSLC Compact + preview iframe for link tooltips

---

## Prerequisites

| Tool | Version |
|------|---------|
| Java | 11 |
| Atlassian Plugin SDK | ≥ 8.2 (`atlas-version`) |
| Maven (bundled with SDK) | ≥ 3.8 |

Install the SDK: https://developer.atlassian.com/server/framework/atlassian-sdk/install-the-atlassian-sdk-on-a-linux-or-mac-system/

---

## Quick Start

### 1 – Clone / copy this project

```bash
cd /path/to/workspace
# (project is already here if you extracted the zip)
cd jira-oslc-addon
```

### 2 – Start Jira with the addon installed (atlas-debug)

```bash
atlas-debug
```

This will:
- Download Jira Data Center 10.3 (first run takes a while)
- Install the addon automatically
- Start Jira at **http://localhost:2990/jira**
- Enable hot-reload (`quickReload`) for faster iteration

Default credentials: `admin` / `admin`

### 3 – Run unit tests only

```bash
atlas-unit-test
# or
mvn test
```

### 4 – Build the JAR without starting Jira

```bash
atlas-package
# Output: target/jira-oslc-addon-1.0.0-SNAPSHOT.jar
```

---

## OSLC Endpoints

All endpoints are under `http://localhost:2990/jira/rest/oslc/1.0/`

| Method | Path | Description |
|--------|------|-------------|
| GET | `/catalog` | Service Provider Catalog |
| GET | `/serviceProviders/{projectKey}` | Service Provider for a project |
| GET | `/serviceProviders/{key}/resources/changeRequests` | List all issues as CRs |
| GET | `/serviceProviders/{key}/resources/changeRequests/{issueKey}` | Single CR |
| GET | `/serviceProviders/{key}/resources/changeRequests/{issueKey}/compact` | OSLC Compact (hover preview descriptor) |
| GET | `/serviceProviders/{key}/resources/query?oslc.where=…` | OSLC Query |
| GET | `/serviceProviders/{key}/resources/links?issueKey={key}` | List outgoing links |
| POST | `/serviceProviders/{key}/resources/links` | Add a link |
| DELETE | `/serviceProviders/{key}/resources/links/{encodedUri}?issueKey=…` | Remove a link |

### Servlet endpoints

| Path | Description |
|------|-------------|
| `/plugins/servlet/oslc/dialogs/selection?projectKey={key}` | OSLC Selection Dialog (popup/iframe) |
| `/plugins/servlet/oslc/preview/{projectKey}/{issueKey}` | Hover preview HTML |
| `/plugins/servlet/oslc/preview/{projectKey}/{issueKey}?size=large` | Large preview |

---

## Content Negotiation

All RDF endpoints support `Accept` header negotiation:

| Accept Header | Format |
|---------------|--------|
| `application/rdf+xml` (default) | RDF/XML |
| `text/turtle` | Turtle |
| `application/ld+json` | JSON-LD |
| `application/x-oslc-compact+xml` | OSLC Compact (for hover preview) |

---

## OSLC Query Examples

```
# All open issues
GET /rest/oslc/1.0/serviceProviders/PROJ/resources/query
    ?oslc.where=oslc_cm:status="Open"

# Issues with "login" in the summary, paginated
GET /rest/oslc/1.0/serviceProviders/PROJ/resources/query
    ?oslc.where=dcterms:title="login"
    &oslc.pageSize=10&oslc.paging=true

# Bugs only
GET /rest/oslc/1.0/serviceProviders/PROJ/resources/query
    ?oslc.where=dcterms:type="Bug"

# Combined
GET /rest/oslc/1.0/serviceProviders/PROJ/resources/query
    ?oslc.where=oslc_cm:status="In Progress" and dcterms:type="Story"
```

---

## Architecture

```
src/main/java/com/example/oslc/
├── model/
│   ├── OslcChangeRequest.java   – OSLC4J-annotated ChangeRequest resource
│   └── OslcLink.java            – Persisted outgoing link entity
├── service/
│   ├── OslcServiceProviderService.java  – Catalog + ServiceProvider RDF
│   ├── OslcChangeRequestService.java    – Issue → ChangeRequest mapping
│   ├── OslcLinkService.java             – SAL PluginSettings link store
│   ├── OslcQueryService.java            – oslc.where → JQL translation
│   └── OslcLinksPanelContextProvider.java – Issue panel template vars
├── rest/
│   ├── CatalogResource.java        – GET /catalog, /serviceProviders/*
│   ├── ChangeRequestResource.java  – GET/POST changeRequests, GET query
│   └── LinkResource.java           – GET/POST/DELETE links
├── servlet/
│   ├── OslcSelectionDialogServlet.java – Selection dialog HTML + AJAX
│   └── OslcPreviewServlet.java         – Hover preview HTML
└── util/
    ├── OslcConstants.java   – All namespace URIs and property names
    └── OslcUrlBuilder.java  – Centralised URL construction
```

---

## Customisation Checklist

- [ ] Change `groupId` / `artifactId` / `atlassian.plugin.key` in `pom.xml`
- [ ] Replace `com.example` package with your own
- [ ] Update vendor name and URL in `atlassian-plugin.xml`
- [ ] Implement `POST /changeRequests` to create Jira issues from OSLC payloads
- [ ] Add OAuth 1.0a consumer/provider support for IBM ELM integration
- [ ] Add `oslc:ResourceShape` endpoint for full spec compliance
- [ ] Extend `OslcQueryService` with additional `oslc.where` operators

---

## Running Against a Remote Jira

To test against an existing Jira instance, build the JAR and install it via
**Jira Admin → Manage apps → Upload app**:

```bash
atlas-package
# Upload: target/jira-oslc-addon-1.0.0-SNAPSHOT.jar
```

package com.example.oslc;

import com.atlassian.sal.api.pluginsettings.PluginSettings;
import com.atlassian.sal.api.pluginsettings.PluginSettingsFactory;
import com.example.oslc.model.OslcLink;
import com.example.oslc.service.OslcLinkService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class OslcLinkServiceTest {

    private OslcLinkService service;
    private Map<String, Object> store;

    @Before
    public void setUp() {
        store = new HashMap<>();

        PluginSettings settings = mock(PluginSettings.class);
        when(settings.get(anyString())).thenAnswer(inv -> store.get(inv.getArgument(0)));
        doAnswer(inv -> { store.put(inv.getArgument(0), inv.getArgument(1)); return null; })
                .when(settings).put(anyString(), anyString());
        doAnswer(inv -> { store.remove(inv.getArgument(0)); return null; })
                .when(settings).remove(anyString());

        PluginSettingsFactory factory = mock(PluginSettingsFactory.class);
        when(factory.createGlobalSettings()).thenReturn(settings);

        service = new OslcLinkService(factory);
    }

    @Test
    public void addAndRetrieve_roundTrip() {
        OslcLink link = new OslcLink("PROJ-1", "http://example.com/resource/42",
                "My Resource", "oslc_cm:ChangeRequest", "relatedChangeRequest");
        service.addLink(link);

        List<OslcLink> links = service.getLinksForIssue("PROJ-1");
        assertEquals(1, links.size());
        assertEquals("http://example.com/resource/42", links.get(0).getRemoteUri());
        assertEquals("My Resource", links.get(0).getLabel());
    }

    @Test
    public void addDuplicate_upserts() {
        service.addLink(new OslcLink("PROJ-1", "http://example.com/r/1",
                "Old Label", "oslc_cm:ChangeRequest", "rel"));
        service.addLink(new OslcLink("PROJ-1", "http://example.com/r/1",
                "New Label", "oslc_cm:ChangeRequest", "rel"));

        List<OslcLink> links = service.getLinksForIssue("PROJ-1");
        assertEquals("Duplicate upsert should result in one link", 1, links.size());
        assertEquals("New Label", links.get(0).getLabel());
    }

    @Test
    public void removeLink_returnsTrueAndDeletesEntry() {
        service.addLink(new OslcLink("PROJ-2", "http://example.com/r/99",
                "Label", "type", "rel"));
        boolean removed = service.removeLink("PROJ-2", "http://example.com/r/99");
        assertTrue(removed);
        assertTrue(service.getLinksForIssue("PROJ-2").isEmpty());
    }

    @Test
    public void removeLink_returnsFalseWhenNotFound() {
        assertFalse(service.removeLink("PROJ-3", "http://example.com/r/does-not-exist"));
    }

    @Test
    public void multipleLinks_storedAndRetrievedInOrder() {
        for (int i = 1; i <= 3; i++) {
            service.addLink(new OslcLink("PROJ-4",
                    "http://example.com/r/" + i, "Resource " + i, "type", "rel"));
        }
        List<OslcLink> links = service.getLinksForIssue("PROJ-4");
        assertEquals(3, links.size());
    }

    @Test
    public void removeAllLinks_clearsStorage() {
        service.addLink(new OslcLink("PROJ-5", "http://example.com/r/1", "L1", "t", "r"));
        service.addLink(new OslcLink("PROJ-5", "http://example.com/r/2", "L2", "t", "r"));
        service.removeAllLinks("PROJ-5");
        assertTrue(service.getLinksForIssue("PROJ-5").isEmpty());
    }
}

package com.example.oslc;

import com.example.oslc.util.OslcUrlBuilder;
import org.junit.Test;
import static org.junit.Assert.*;

public class OslcUrlBuilderTest {

    private static final String BASE = "http://localhost:2990/jira";
    private final OslcUrlBuilder urls = new OslcUrlBuilder(BASE);

    @Test
    public void catalogUrl_containsRestPath() {
        assertTrue(urls.catalogUrl().contains("/rest/oslc/1.0/catalog"));
    }

    @Test
    public void serviceProviderUrl_containsProjectKey() {
        String url = urls.serviceProviderUrl("MYPROJ");
        assertTrue("Expected projectKey in URL: " + url, url.contains("MYPROJ"));
        assertTrue(url.contains("/serviceProviders/MYPROJ"));
    }

    @Test
    public void changeRequestUrl_containsBothKeys() {
        String url = urls.changeRequestUrl("MYPROJ", "MYPROJ-42");
        assertTrue(url.contains("MYPROJ-42"));
        assertTrue(url.contains("changeRequests"));
    }

    @Test
    public void queryUrl_isUnderServiceProvider() {
        String url = urls.queryUrl("PROJ");
        assertTrue(url.contains("/serviceProviders/PROJ/resources/query"));
    }

    @Test
    public void compactUrl_endsWithCompact() {
        String url = urls.compactUrl("PROJ", "PROJ-1");
        assertTrue(url.endsWith("/compact"));
    }

    @Test
    public void selectionDialogUrl_isServletPath() {
        String url = urls.selectionDialogUrl("PROJ");
        assertTrue("Expected servlet path: " + url, url.contains("/plugins/servlet/oslc/dialogs/selection"));
        assertTrue(url.contains("projectKey=PROJ"));
    }

    @Test
    public void previewUrl_containsIssueKey() {
        String url = urls.previewUrl("PROJ", "PROJ-7");
        assertTrue(url.contains("PROJ-7"));
        assertTrue(url.contains("/plugins/servlet/oslc/preview/"));
    }
}

package com.example.oslc.util;

/**
 * Central repository for all OSLC / RDF / Dublin-Core namespace URIs and
 * well-known property names used throughout the plugin.
 */
public final class OslcConstants {

    private OslcConstants() {}

    // -----------------------------------------------------------------------
    // Namespace URIs
    // -----------------------------------------------------------------------
    public static final String OSLC_CORE_NS     = "http://open-services.net/ns/core#";
    public static final String OSLC_CM_NS       = "http://open-services.net/ns/cm#";
    public static final String RDF_NS           = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    public static final String RDFS_NS          = "http://www.w3.org/2000/01/rdf-schema#";
    public static final String DCTERMS_NS       = "http://purl.org/dc/terms/";
    public static final String FOAF_NS          = "http://xmlns.com/foaf/0.1/";
    public static final String XSD_NS           = "http://www.w3.org/2001/XMLSchema#";

    // -----------------------------------------------------------------------
    // OSLC Core resource types
    // -----------------------------------------------------------------------
    public static final String TYPE_SERVICE_PROVIDER_CATALOG = OSLC_CORE_NS + "ServiceProviderCatalog";
    public static final String TYPE_SERVICE_PROVIDER         = OSLC_CORE_NS + "ServiceProvider";
    public static final String TYPE_SERVICE                  = OSLC_CORE_NS + "Service";
    public static final String TYPE_CREATION_FACTORY         = OSLC_CORE_NS + "CreationFactory";
    public static final String TYPE_QUERY_CAPABILITY         = OSLC_CORE_NS + "QueryCapability";
    public static final String TYPE_DIALOG                   = OSLC_CORE_NS + "Dialog";
    public static final String TYPE_PREVIEW                  = OSLC_CORE_NS + "Preview";
    public static final String TYPE_RESOURCE_SHAPE           = OSLC_CORE_NS + "ResourceShape";

    // -----------------------------------------------------------------------
    // OSLC CM resource types
    // -----------------------------------------------------------------------
    public static final String TYPE_CHANGE_REQUEST   = OSLC_CM_NS + "ChangeRequest";
    public static final String TYPE_DEFECT           = OSLC_CM_NS + "Defect";
    public static final String TYPE_ENHANCEMENT      = OSLC_CM_NS + "Enhancement";
    public static final String TYPE_TASK             = OSLC_CM_NS + "Task";

    // -----------------------------------------------------------------------
    // OSLC CM status values
    // -----------------------------------------------------------------------
    public static final String STATUS_OPEN       = OSLC_CM_NS + "Open";
    public static final String STATUS_IN_PROGRESS = OSLC_CM_NS + "Inprogress";
    public static final String STATUS_FIXED      = OSLC_CM_NS + "Fixed";
    public static final String STATUS_CLOSED     = OSLC_CM_NS + "Closed";

    // -----------------------------------------------------------------------
    // OSLC Core properties
    // -----------------------------------------------------------------------
    public static final String PROP_SERVICE_PROVIDER  = OSLC_CORE_NS + "serviceProvider";
    public static final String PROP_INSTANCE_SHAPE    = OSLC_CORE_NS + "instanceShape";
    public static final String PROP_SHORT_TITLE       = OSLC_CORE_NS + "shortTitle";
    public static final String PROP_SMALL_PREVIEW     = OSLC_CORE_NS + "smallPreview";
    public static final String PROP_LARGE_PREVIEW     = OSLC_CORE_NS + "largePreview";
    public static final String PROP_DOCUMENT          = OSLC_CORE_NS + "document";
    public static final String PROP_HINT_WIDTH        = OSLC_CORE_NS + "hintWidth";
    public static final String PROP_HINT_HEIGHT       = OSLC_CORE_NS + "hintHeight";

    // -----------------------------------------------------------------------
    // Content-type negotiation
    // -----------------------------------------------------------------------
    public static final String CT_RDF_XML      = "application/rdf+xml";
    public static final String CT_TURTLE       = "text/turtle";
    public static final String CT_JSON_LD      = "application/ld+json";
    public static final String CT_OSLC_COMPACT = "application/x-oslc-compact+xml";
    public static final String CT_HTML         = "text/html";

    // -----------------------------------------------------------------------
    // REST path segments  (must match atlassian-plugin.xml rest path="/oslc")
    // -----------------------------------------------------------------------
    public static final String PATH_CATALOG          = "/catalog";
    public static final String PATH_SERVICE_PROVIDER = "/serviceProviders/{projectKey}";
    public static final String PATH_CHANGE_REQUESTS  = "/serviceProviders/{projectKey}/resources/changeRequests";
    public static final String PATH_CHANGE_REQUEST   = "/serviceProviders/{projectKey}/resources/changeRequests/{issueKey}";
    public static final String PATH_QUERY            = "/serviceProviders/{projectKey}/resources/query";
    public static final String PATH_COMPACT          = "/serviceProviders/{projectKey}/resources/changeRequests/{issueKey}/compact";
    public static final String PATH_RESOURCE_SHAPE   = "/resourceShapes/changeRequest";

    // -----------------------------------------------------------------------
    // Plugin settings keys (for persisting external links via SAL)
    // -----------------------------------------------------------------------
    public static final String SETTINGS_LINKS_PREFIX = "com.example.oslc.links.";
}

package com.example.oslc.rest;

import com.example.oslc.model.OslcLink;
import com.example.oslc.service.OslcLinkService;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * REST resource for managing OSLC resource links stored against a Jira issue.
 *
 *   GET    /serviceProviders/{projectKey}/resources/links?issueKey={key}
 *   POST   /serviceProviders/{projectKey}/resources/links
 *   DELETE /serviceProviders/{projectKey}/resources/links/{encodedRemoteUri}?issueKey={key}
 */
@Path("/serviceProviders/{projectKey}/resources/links")
@Named
public class LinkResource {

    private final OslcLinkService linkService;

    @Inject
    public LinkResource(OslcLinkService linkService) {
        this.linkService = linkService;
    }

    // -----------------------------------------------------------------------
    // GET – list links for an issue
    // -----------------------------------------------------------------------

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLinks(
            @PathParam("projectKey") String projectKey,
            @QueryParam("issueKey")  String issueKey) {

        if (issueKey == null || issueKey.isBlank()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"error\":\"issueKey query parameter is required\"}").build();
        }

        List<OslcLink> links = linkService.getLinksForIssue(issueKey);
        return Response.ok(toJson(links))
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .build();
    }

    // -----------------------------------------------------------------------
    // POST – add a new link
    // Body: JSON   { "issueKey":"PROJ-1", "remoteUri":"http://...",
    //                "label":"...", "resourceType":"...", "linkType":"..." }
    // -----------------------------------------------------------------------

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addLink(
            @PathParam("projectKey") String projectKey,
            String body) {

        try {
            OslcLink link = fromJson(body);
            if (link.getRemoteUri() == null || link.getRemoteUri().isBlank()) {
                return Response.status(400).entity("{\"error\":\"remoteUri is required\"}").build();
            }
            if (link.getIssueKey() == null || link.getIssueKey().isBlank()) {
                return Response.status(400).entity("{\"error\":\"issueKey is required\"}").build();
            }
            linkService.addLink(link);
            return Response.status(Response.Status.CREATED)
                    .entity(linkToJson(link)).build();
        } catch (Exception e) {
            return Response.status(400).entity("{\"error\":\"" + e.getMessage() + "\"}").build();
        }
    }

    // -----------------------------------------------------------------------
    // DELETE – remove a specific link by remoteUri
    // -----------------------------------------------------------------------

    @DELETE
    @Path("/{encodedRemoteUri}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response removeLink(
            @PathParam("projectKey")       String projectKey,
            @PathParam("encodedRemoteUri") String encodedRemoteUri,
            @QueryParam("issueKey")        String issueKey) {

        if (issueKey == null || issueKey.isBlank()) {
            return Response.status(400)
                    .entity("{\"error\":\"issueKey query parameter is required\"}").build();
        }

        String remoteUri = URLDecoder.decode(encodedRemoteUri, StandardCharsets.UTF_8);
        boolean removed = linkService.removeLink(issueKey, remoteUri);
        if (removed) {
            return Response.ok("{\"status\":\"deleted\"}").build();
        } else {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("{\"error\":\"Link not found\"}").build();
        }
    }

    // -----------------------------------------------------------------------
    // Minimal JSON helpers (avoid pulling in Jackson for now)
    // -----------------------------------------------------------------------

    private String toJson(List<OslcLink> links) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < links.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(linkToJson(links.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    private String linkToJson(OslcLink l) {
        return "{"
                + "\"issueKey\":"     + jsonStr(l.getIssueKey())     + ","
                + "\"remoteUri\":"    + jsonStr(l.getRemoteUri())    + ","
                + "\"label\":"        + jsonStr(l.getLabel())        + ","
                + "\"resourceType\":" + jsonStr(l.getResourceType()) + ","
                + "\"linkType\":"     + jsonStr(l.getLinkType())     + ","
                + "\"created\":"      + l.getCreated()
                + "}";
    }

    private String jsonStr(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    /**
     * Minimal JSON object parser (supports flat key:"value" pairs only).
     * Replace with Jackson ObjectMapper if the dependency is added to the POM.
     */
    private OslcLink fromJson(String json) {
        OslcLink link = new OslcLink();
        link.setIssueKey(extractJsonString(json, "issueKey"));
        link.setRemoteUri(extractJsonString(json, "remoteUri"));
        link.setLabel(extractJsonString(json, "label"));
        link.setResourceType(extractJsonString(json, "resourceType"));
        link.setLinkType(extractJsonString(json, "linkType"));
        link.setCreated(System.currentTimeMillis());
        return link;
    }

    private String extractJsonString(String json, String key) {
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx < 0) return null;
        int colon = json.indexOf(':', idx + pattern.length());
        if (colon < 0) return null;
        int quote1 = json.indexOf('"', colon + 1);
        if (quote1 < 0) return null;
        int quote2 = json.indexOf('"', quote1 + 1);
        if (quote2 < 0) return null;
        return json.substring(quote1 + 1, quote2);
    }
}

package com.example.oslc.service;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.plugin.webfragment.contextproviders.AbstractJiraContextProvider;
import com.atlassian.jira.plugin.webfragment.model.JiraHelper;
import com.atlassian.jira.user.ApplicationUser;
import com.example.oslc.model.OslcLink;
import com.example.oslc.util.OslcUrlBuilder;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Provides template variables for the OSLC Links panel shown on the
 * Jira issue view page (oslc-links-panel.vm).
 *
 * Variables exposed:
 *   $oslcLinks       – List<OslcLink>
 *   $issueKey        – String
 *   $addLinkUrl      – URL of the REST endpoint to POST a new link
 *   $deleteLinkBase  – Base URL for DELETE /links/{remoteUri}
 *   $dialogBaseUrl   – Base URL for the selection dialog per project
 */
@Scanned
@Named
public class OslcLinksPanelContextProvider extends AbstractJiraContextProvider {

    private final OslcLinkService oslcLinkService;
    private final OslcUrlBuilder urls;

    @Inject
    public OslcLinksPanelContextProvider(OslcLinkService oslcLinkService,
                                          OslcUrlBuilder urls) {
        this.oslcLinkService = oslcLinkService;
        this.urls = urls;
    }

    @Override
    public Map<String, Object> getContextMap(ApplicationUser user, JiraHelper jiraHelper) {
        Map<String, Object> context = new HashMap<>();

        Issue issue = (Issue) jiraHelper.getContextParams().get("issue");
        if (issue == null) return context;

        String issueKey  = issue.getKey();
        String projectKey = issue.getProjectObject().getKey();

        List<OslcLink> links = oslcLinkService.getLinksForIssue(issueKey);

        context.put("oslcLinks",      links);
        context.put("issueKey",       issueKey);
        context.put("projectKey",     projectKey);
        context.put("addLinkUrl",
                "/rest/oslc/1.0/serviceProviders/" + projectKey + "/resources/links");
        context.put("deleteLinkBase",
                "/rest/oslc/1.0/serviceProviders/" + projectKey + "/resources/links/");
        context.put("dialogBaseUrl",  urls.selectionDialogUrl(projectKey));

        return context;
    }
}

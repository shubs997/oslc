package com.example.oslc.servlet;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.jql.builder.JqlQueryBuilder;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.query.Query;
import com.example.oslc.util.OslcUrlBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * OSLC Selection Dialog – served at /plugins/servlet/oslc/dialogs/selection
 *
 * This is the delegated UI that external OSLC clients (e.g. IBM ELM, Polarion)
 * open in an iframe or popup to let users pick one or more Jira issues.
 *
 * On selection the dialog posts an OSLC windowSelection event to the opener.
 *
 * Query params:
 *   projectKey  – filter to a specific project (optional)
 *   term        – free-text search term (optional, used by AJAX filter)
 *   oslc.response.type – "oslc#ResourceSelection" (standard OSLC header)
 */
@Named
public class OslcSelectionDialogServlet extends HttpServlet {

    private static final Logger log = LoggerFactory.getLogger(OslcSelectionDialogServlet.class);
    private static final int PAGE_SIZE = 25;

    private final ProjectManager projectManager;
    private final OslcUrlBuilder urls;

    @Inject
    public OslcSelectionDialogServlet(ProjectManager projectManager,
                                       OslcUrlBuilder urls) {
        this.projectManager = projectManager;
        this.urls           = urls;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String projectKey = req.getParameter("projectKey");
        String term       = req.getParameter("term");
        boolean ajax      = "true".equals(req.getParameter("ajax"));

        ApplicationUser user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser();

        List<Issue> issues = searchIssues(user, projectKey, term);

        resp.setContentType("text/html;charset=UTF-8");
        resp.setHeader("X-Frame-Options", "SAMEORIGIN");

        PrintWriter out = resp.getWriter();

        if (ajax) {
            // Return just the results table fragment for live filtering
            writeResultsTable(out, issues, projectKey);
        } else {
            // Full dialog page
            writeFullDialog(out, issues, projectKey, term);
        }
    }

    // -----------------------------------------------------------------------
    // Full page
    // -----------------------------------------------------------------------

    private void writeFullDialog(PrintWriter out, List<Issue> issues,
                                  String projectKey, String term) {
        out.println("<!DOCTYPE html>");
        out.println("<html lang=\"en\">");
        out.println("<head>");
        out.println("  <meta charset=\"UTF-8\">");
        out.println("  <title>Select Jira Issue – OSLC</title>");
        out.println("  <style>");
        out.println("    body { font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
                +          " margin:0; padding:12px; background:#fff; font-size:13px; }");
        out.println("    h2   { font-size:16px; margin:0 0 10px; color:#172b4d; }");
        out.println("    .search-bar { display:flex; gap:6px; margin-bottom:10px; }");
        out.println("    .search-bar input  { flex:1; padding:6px 8px; border:1px solid #ccc;"
                +          " border-radius:3px; }");
        out.println("    .search-bar button { padding:6px 12px; background:#0052cc; color:#fff;"
                +          " border:none; border-radius:3px; cursor:pointer; }");
        out.println("    table  { width:100%; border-collapse:collapse; }");
        out.println("    th,td  { text-align:left; padding:6px 8px; border-bottom:1px solid #e0e0e0; }");
        out.println("    th     { background:#f4f5f7; font-weight:600; }");
        out.println("    tr:hover { background:#f0f4ff; }");
        out.println("    .select-btn { background:#0052cc; color:#fff; border:none;"
                +          " border-radius:3px; padding:3px 10px; cursor:pointer; font-size:12px; }");
        out.println("    .select-btn:hover { background:#0065ff; }");
        out.println("    #results { margin-top:4px; }");
        out.println("  </style>");
        out.println("</head>");
        out.println("<body>");
        out.println("  <h2>Select a Jira Issue</h2>");

        // Search bar
        out.println("  <div class=\"search-bar\">");
        out.println("    <input id=\"searchInput\" type=\"text\" placeholder=\"Search by summary…\""
                + " value=\"" + esc(term != null ? term : "") + "\">");
        if (projectKey != null) {
            out.println("    <input type=\"hidden\" id=\"projectKey\" value=\"" + esc(projectKey) + "\">");
        }
        out.println("    <button onclick=\"doSearch()\">Search</button>");
        out.println("  </div>");

        out.println("  <div id=\"results\">");
        writeResultsTable(out, issues, projectKey);
        out.println("  </div>");

        // OSLC windowSelection JavaScript
        out.println("  <script>");
        out.println("  function selectIssue(uri, label, type) {");
        out.println("    var results = [{ label: label, resource: uri, resourceType: type }];");
        out.println("    var message = JSON.stringify({ 'oslc-response': {"
                + " 'oslc:results': results } });");
        out.println("    if (window.opener) {");
        out.println("      window.opener.postMessage(message, '*');");
        out.println("      window.close();");
        out.println("    } else if (window.parent !== window) {");
        out.println("      window.parent.postMessage(message, '*');");
        out.println("    }");
        out.println("  }");
        out.println("  function doSearch() {");
        out.println("    var term = document.getElementById('searchInput').value;");
        out.println("    var pk   = document.getElementById('projectKey');");
        out.println("    var qs   = 'ajax=true&term=' + encodeURIComponent(term);");
        out.println("    if (pk) qs += '&projectKey=' + encodeURIComponent(pk.value);");
        out.println("    fetch('/plugins/servlet/oslc/dialogs/selection?' + qs)");
        out.println("      .then(r => r.text())");
        out.println("      .then(html => { document.getElementById('results').innerHTML = html; });");
        out.println("  }");
        out.println("  document.getElementById('searchInput').addEventListener('keydown', function(e) {");
        out.println("    if (e.key === 'Enter') doSearch();");
        out.println("  });");
        out.println("  </script>");
        out.println("</body></html>");
    }

    // -----------------------------------------------------------------------
    // Results table fragment (also used by AJAX)
    // -----------------------------------------------------------------------

    private void writeResultsTable(PrintWriter out, List<Issue> issues, String projectKey) {
        if (issues.isEmpty()) {
            out.println("<p style=\"color:#666;\">No issues found.</p>");
            return;
        }
        out.println("<table>");
        out.println("  <thead><tr><th>Key</th><th>Summary</th><th>Type</th>"
                + "<th>Status</th><th></th></tr></thead>");
        out.println("  <tbody>");
        for (Issue issue : issues) {
            String key     = esc(issue.getKey());
            String summary = esc(issue.getSummary());
            String type    = issue.getIssueType() != null ? esc(issue.getIssueType().getName()) : "";
            String status  = issue.getStatus()    != null ? esc(issue.getStatus().getName()) : "";
            String pk      = projectKey != null ? projectKey : issue.getProjectObject().getKey();
            String uri     = urls.changeRequestUrl(pk, issue.getKey());
            String label   = issue.getKey() + ": " + (issue.getSummary() != null
                    ? (issue.getSummary().length() > 60
                        ? issue.getSummary().substring(0, 59) + "…"
                        : issue.getSummary())
                    : "");

            out.println("  <tr>");
            out.println("    <td><code>" + key + "</code></td>");
            out.println("    <td>" + summary + "</td>");
            out.println("    <td>" + type    + "</td>");
            out.println("    <td>" + status  + "</td>");
            out.println("    <td><button class=\"select-btn\""
                    + " onclick=\"selectIssue('" + esc(uri) + "','"
                    + esc(label) + "','http://open-services.net/ns/cm#ChangeRequest')\""
                    + ">Select</button></td>");
            out.println("  </tr>");
        }
        out.println("  </tbody></table>");
    }

    // -----------------------------------------------------------------------
    // Search
    // -----------------------------------------------------------------------

    private List<Issue> searchIssues(ApplicationUser user, String projectKey, String term) {
        SearchService searchService = ComponentAccessor.getComponent(SearchService.class);
        JqlQueryBuilder qb = JqlQueryBuilder.newBuilder();

        if (projectKey != null && !projectKey.isBlank()) {
            qb.where().project(projectKey);
        }
        if (term != null && !term.isBlank()) {
            qb.where().and().summary("*" + term + "*");
        }
        qb.orderBy().createdDate(false);

        Query query = qb.buildQuery();
        try {
            SearchResults<Issue> results = searchService.search(
                    user, query, PagerFilter.newPageAlignedFilter(0, PAGE_SIZE));
            return results.getResults();
        } catch (SearchException e) {
            log.error("Selection dialog search failed", e);
            return List.of();
        }
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}

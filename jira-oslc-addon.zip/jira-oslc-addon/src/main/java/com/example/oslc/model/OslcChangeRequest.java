package com.example.oslc.model;

import org.eclipse.lyo.oslc4j.core.annotation.*;
import org.eclipse.lyo.oslc4j.core.model.AbstractResource;
import org.eclipse.lyo.oslc4j.core.model.OslcConstants;

import javax.xml.namespace.QName;
import java.net.URI;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static com.example.oslc.util.OslcConstants.*;

/**
 * OSLC Change Management 2.0 – ChangeRequest resource.
 *
 * Maps to a Jira Issue. All property names follow the OSLC-CM 2.0 specification.
 */
@OslcNamespace(OSLC_CM_NS)
@OslcResourceType(TYPE_CHANGE_REQUEST)
@OslcShape(OSLC_CORE_NS + "resourceShapes/changeRequest")
@OslcName("ChangeRequest")
public class OslcChangeRequest extends AbstractResource {

    // -----------------------------------------------------------------------
    // Dublin Core properties
    // -----------------------------------------------------------------------
    private String      title;
    private String      description;
    private String      identifier;     // issue key, e.g. "PROJ-42"
    private URI         creator;
    private URI         contributor;
    private Date        created;
    private Date        modified;

    // -----------------------------------------------------------------------
    // OSLC CM-specific
    // -----------------------------------------------------------------------
    private boolean     closed;
    private boolean     inProgress;
    private boolean     fixed;
    private boolean     approved;
    private boolean     reviewed;
    private boolean     verified;

    private String      status;
    private String      priority;
    private String      type;           // Bug / Story / Task …

    /** Back-link to the Jira issue browse URL. */
    private URI         subject;

    /** Related external OSLC resources (outgoing links). */
    private Set<URI>    relatedResources = new HashSet<>();

    /** OSLC service provider that owns this resource. */
    private URI         serviceProvider;

    /** Short title used in compact representation / hover previews. */
    private String      shortTitle;

    // -----------------------------------------------------------------------
    // Constructors
    // -----------------------------------------------------------------------
    public OslcChangeRequest() { super(); }

    public OslcChangeRequest(URI about) { super(about); }

    // -----------------------------------------------------------------------
    // Dublin Core getters / setters
    // -----------------------------------------------------------------------
    @OslcDescription("Title of the change request")
    @OslcPropertyDefinition(DCTERMS_NS + "title")
    @OslcTitle("Title")
    @OslcOccurs(org.eclipse.lyo.oslc4j.core.annotation.OslcOccurs.ExactlyOne)
    @OslcValueType(org.eclipse.lyo.oslc4j.core.model.OslcConstants.STRING_TYPE)
    public String getTitle()               { return title; }
    public void setTitle(String title)     { this.title = title; }

    @OslcPropertyDefinition(DCTERMS_NS + "description")
    @OslcTitle("Description")
    public String getDescription()                     { return description; }
    public void setDescription(String description)     { this.description = description; }

    @OslcPropertyDefinition(DCTERMS_NS + "identifier")
    @OslcTitle("Identifier")
    public String getIdentifier()                  { return identifier; }
    public void setIdentifier(String identifier)   { this.identifier = identifier; }

    @OslcPropertyDefinition(DCTERMS_NS + "creator")
    @OslcTitle("Creator")
    @OslcRange(FOAF_NS + "Person")
    public URI getCreator()            { return creator; }
    public void setCreator(URI creator){ this.creator = creator; }

    @OslcPropertyDefinition(DCTERMS_NS + "contributor")
    @OslcTitle("Contributor")
    public URI getContributor()                    { return contributor; }
    public void setContributor(URI contributor)    { this.contributor = contributor; }

    @OslcPropertyDefinition(DCTERMS_NS + "created")
    @OslcTitle("Created")
    public Date getCreated()           { return created; }
    public void setCreated(Date d)     { this.created = d; }

    @OslcPropertyDefinition(DCTERMS_NS + "modified")
    @OslcTitle("Modified")
    public Date getModified()          { return modified; }
    public void setModified(Date d)    { this.modified = d; }

    // -----------------------------------------------------------------------
    // OSLC CM properties
    // -----------------------------------------------------------------------
    @OslcPropertyDefinition(OSLC_CM_NS + "closed")
    @OslcTitle("Closed")
    public boolean isClosed()              { return closed; }
    public void setClosed(boolean closed)  { this.closed = closed; }

    @OslcPropertyDefinition(OSLC_CM_NS + "inprogress")
    @OslcTitle("In Progress")
    public boolean isInProgress()                  { return inProgress; }
    public void setInProgress(boolean inProgress)  { this.inProgress = inProgress; }

    @OslcPropertyDefinition(OSLC_CM_NS + "fixed")
    @OslcTitle("Fixed")
    public boolean isFixed()               { return fixed; }
    public void setFixed(boolean fixed)    { this.fixed = fixed; }

    @OslcPropertyDefinition(OSLC_CM_NS + "approved")
    @OslcTitle("Approved")
    public boolean isApproved()                { return approved; }
    public void setApproved(boolean approved)  { this.approved = approved; }

    @OslcPropertyDefinition(OSLC_CM_NS + "reviewed")
    @OslcTitle("Reviewed")
    public boolean isReviewed()                { return reviewed; }
    public void setReviewed(boolean reviewed)  { this.reviewed = reviewed; }

    @OslcPropertyDefinition(OSLC_CM_NS + "verified")
    @OslcTitle("Verified")
    public boolean isVerified()                { return verified; }
    public void setVerified(boolean verified)  { this.verified = verified; }

    @OslcPropertyDefinition(OSLC_CM_NS + "status")
    @OslcTitle("Status")
    public String getStatus()              { return status; }
    public void setStatus(String status)   { this.status = status; }

    @OslcPropertyDefinition(OSLC_CM_NS + "priority")
    @OslcTitle("Priority")
    public String getPriority()                { return priority; }
    public void setPriority(String priority)   { this.priority = priority; }

    @OslcPropertyDefinition(DCTERMS_NS + "type")
    @OslcTitle("Type")
    public String getType()            { return type; }
    public void setType(String type)   { this.type = type; }

    @OslcPropertyDefinition(DCTERMS_NS + "subject")
    @OslcTitle("Issue URL")
    public URI getSubject()            { return subject; }
    public void setSubject(URI u)      { this.subject = u; }

    @OslcPropertyDefinition(OSLC_CM_NS + "relatedChangeRequest")
    @OslcTitle("Related Resources")
    @OslcRange(TYPE_CHANGE_REQUEST)
    public Set<URI> getRelatedResources()              { return relatedResources; }
    public void setRelatedResources(Set<URI> uris)     { this.relatedResources = uris; }
    public void addRelatedResource(URI uri)            { this.relatedResources.add(uri); }

    @OslcPropertyDefinition(OSLC_CORE_NS + "serviceProvider")
    @OslcTitle("Service Provider")
    public URI getServiceProvider()                    { return serviceProvider; }
    public void setServiceProvider(URI sp)             { this.serviceProvider = sp; }

    @OslcPropertyDefinition(OSLC_CORE_NS + "shortTitle")
    @OslcTitle("Short Title")
    public String getShortTitle()                  { return shortTitle; }
    public void setShortTitle(String shortTitle)   { this.shortTitle = shortTitle; }
}

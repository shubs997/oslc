package com.example.oslc.servlet;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.sal.api.ApplicationProperties;
import com.atlassian.sal.api.UrlMode;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * OSLC Preview Servlet – /plugins/servlet/oslc/preview/{projectKey}/{issueKey}
 *
 * Returns an HTML "compact" representation of a Jira issue, rendered inside
 * a hover popup by the external OSLC client.
 *
 * Size variants:
 *   (default / ?size=small) → compact card  ~400×120px
 *   ?size=large             → expanded card ~600×400px
 */
@Named
public class OslcPreviewServlet extends HttpServlet {

    private static final Logger log = LoggerFactory.getLogger(OslcPreviewServlet.class);

    private final IssueManager issueManager;
    private final ApplicationProperties applicationProperties;

    @Inject
    public OslcPreviewServlet(
            @ComponentImport IssueManager issueManager,
            @ComponentImport ApplicationProperties applicationProperties) {
        this.issueManager = issueManager;
        this.applicationProperties = applicationProperties;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // URL pattern: /oslc/preview/{projectKey}/{issueKey}
        String pathInfo = req.getPathInfo();           // e.g. "/PROJ/PROJ-42"
        if (pathInfo == null || pathInfo.length() < 2) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing path info");
            return;
        }

        String[] parts      = pathInfo.substring(1).split("/", 2);
        String   issueKey   = parts.length > 1 ? parts[1] : parts[0];
        boolean  large      = "large".equalsIgnoreCase(req.getParameter("size"));

        Issue issue = issueManager.getIssueByCurrentKey(issueKey);
        if (issue == null) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Issue not found: " + issueKey);
            return;
        }

        resp.setContentType("text/html;charset=UTF-8");
        // Allow the external client to embed this in an iframe
        resp.setHeader("X-Frame-Options", "ALLOWALL");
        resp.setHeader("Content-Security-Policy", "frame-ancestors *");

        PrintWriter out = resp.getWriter();
        if (large) {
            writeLargePreview(out, issue);
        } else {
            writeSmallPreview(out, issue);
        }
    }

    // -----------------------------------------------------------------------
    // Small preview (~400×120px)
    // -----------------------------------------------------------------------

    private void writeSmallPreview(PrintWriter out, Issue issue) {
        String browseUrl = applicationProperties.getBaseUrl(UrlMode.ABSOLUTE)
                + "/browse/" + issue.getKey();
        String statusName  = issue.getStatus()    != null ? issue.getStatus().getName()    : "—";
        String priorityName= issue.getPriority()  != null ? issue.getPriority().getName()  : "—";
        String typeName    = issue.getIssueType() != null ? issue.getIssueType().getName() : "—";
        String assignee    = issue.getAssignee()  != null ? issue.getAssignee().getDisplayName() : "Unassigned";
        String summary     = issue.getSummary()   != null ? issue.getSummary() : "";

        out.println("<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\">");
        out.println("<style>");
        out.println("  * { box-sizing:border-box; margin:0; padding:0; }");
        out.println("  body { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
                + " font-size:12px; padding:10px; background:#fff; color:#172b4d; }");
        out.println("  .key  { font-weight:700; color:#0052cc; text-decoration:none; font-size:13px; }");
        out.println("  .key:hover { text-decoration:underline; }");
        out.println("  .summary { margin:4px 0 6px; font-size:12px; line-height:1.4; }");
        out.println("  .meta { display:flex; gap:12px; color:#5e6c84; font-size:11px; }");
        out.println("  .badge { background:#dfe1e6; border-radius:3px; padding:1px 5px; }");
        out.println("</style></head><body>");
        out.println("  <a class=\"key\" href=\"" + esc(browseUrl) + "\" target=\"_blank\">"
                + esc(issue.getKey()) + "</a>");
        out.println("  <div class=\"summary\">" + esc(summary) + "</div>");
        out.println("  <div class=\"meta\">");
        out.println("    <span class=\"badge\">" + esc(typeName) + "</span>");
        out.println("    <span class=\"badge\">" + esc(statusName) + "</span>");
        out.println("    <span class=\"badge\">" + esc(priorityName) + "</span>");
        out.println("    <span>" + esc(assignee) + "</span>");
        out.println("  </div>");
        out.println("</body></html>");
    }

    // -----------------------------------------------------------------------
    // Large preview (~600×400px)
    // -----------------------------------------------------------------------

    private void writeLargePreview(PrintWriter out, Issue issue) {
        String browseUrl   = applicationProperties.getBaseUrl(UrlMode.ABSOLUTE)
                + "/browse/" + issue.getKey();
        String statusName  = issue.getStatus()    != null ? issue.getStatus().getName()    : "—";
        String priorityName= issue.getPriority()  != null ? issue.getPriority().getName()  : "—";
        String typeName    = issue.getIssueType() != null ? issue.getIssueType().getName() : "—";
        String assignee    = issue.getAssignee()  != null ? issue.getAssignee().getDisplayName() : "Unassigned";
        String reporter    = issue.getReporter()  != null ? issue.getReporter().getDisplayName()  : "—";
        String project     = issue.getProjectObject() != null ? issue.getProjectObject().getName() : "—";
        String summary     = issue.getSummary()   != null ? issue.getSummary() : "";
        String description = issue.getDescription() != null ? issue.getDescription() : "(no description)";
        if (description.length() > 500) description = description.substring(0, 499) + "…";

        out.println("<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\">");
        out.println("<style>");
        out.println("  * { box-sizing:border-box; margin:0; padding:0; }");
        out.println("  body { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;"
                + " font-size:13px; padding:16px; background:#fff; color:#172b4d; overflow-y:auto; }");
        out.println("  h1 { font-size:16px; margin-bottom:8px; }");
        out.println("  .key { font-weight:700; color:#0052cc; text-decoration:none; }");
        out.println("  .key:hover { text-decoration:underline; }");
        out.println("  .grid { display:grid; grid-template-columns:1fr 1fr; gap:8px 24px;"
                + " margin:12px 0; font-size:12px; }");
        out.println("  .label { color:#5e6c84; font-weight:600; font-size:11px;"
                + " text-transform:uppercase; }");
        out.println("  .desc  { margin-top:12px; padding-top:12px;"
                + " border-top:1px solid #e0e0e0; font-size:12px; line-height:1.5;"
                + " color:#42526e; white-space:pre-wrap; }");
        out.println("  .badge { display:inline-block; background:#dfe1e6; border-radius:3px;"
                + " padding:2px 6px; }");
        out.println("</style></head><body>");
        out.println("  <h1><a class=\"key\" href=\"" + esc(browseUrl) + "\" target=\"_blank\">"
                + esc(issue.getKey()) + "</a></h1>");
        out.println("  <div style=\"font-size:14px;margin-bottom:8px;\">" + esc(summary) + "</div>");
        out.println("  <div class=\"grid\">");
        field(out, "Project",  project);
        field(out, "Type",     "<span class=\"badge\">" + esc(typeName) + "</span>");
        field(out, "Status",   "<span class=\"badge\">" + esc(statusName) + "</span>");
        field(out, "Priority", "<span class=\"badge\">" + esc(priorityName) + "</span>");
        field(out, "Assignee", assignee);
        field(out, "Reporter", reporter);
        if (issue.getCreated() != null)
            field(out, "Created", issue.getCreated().toString());
        if (issue.getUpdated() != null)
            field(out, "Updated", issue.getUpdated().toString());
        out.println("  </div>");
        out.println("  <div class=\"desc\">" + esc(description) + "</div>");
        out.println("</body></html>");
    }

    private void field(PrintWriter out, String label, String value) {
        out.println("  <div><div class=\"label\">" + label + "</div><div>" + value + "</div></div>");
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}

package com.example.oslc.model;

import java.net.URI;

/**
 * Represents a single outgoing OSLC link stored against a Jira issue.
 *
 * Persisted as JSON in Atlassian SAL PluginSettings:
 *   key  = "com.example.oslc.links.<issueKey>"
 *   value = JSON array of OslcLink objects
 */
public class OslcLink {

    /** The remote OSLC resource URI. */
    private String remoteUri;

    /** Human-readable label fetched from the remote resource (optional cache). */
    private String label;

    /** OSLC resource type URI (e.g. oslc_cm:ChangeRequest). */
    private String resourceType;

    /** The Jira issue key this link is attached to. */
    private String issueKey;

    /** OSLC link type (e.g. "relatedChangeRequest", "tracksRequirement"). */
    private String linkType;

    /** Timestamp (epoch ms) when the link was created. */
    private long created;

    public OslcLink() {}

    public OslcLink(String issueKey, String remoteUri, String label, String resourceType, String linkType) {
        this.issueKey     = issueKey;
        this.remoteUri    = remoteUri;
        this.label        = label;
        this.resourceType = resourceType;
        this.linkType     = linkType;
        this.created      = System.currentTimeMillis();
    }

    // -----------------------------------------------------------------------
    // Getters / Setters
    // -----------------------------------------------------------------------
    public String getRemoteUri()                   { return remoteUri; }
    public void   setRemoteUri(String remoteUri)   { this.remoteUri = remoteUri; }

    public String getLabel()                   { return label; }
    public void   setLabel(String label)       { this.label = label; }

    public String getResourceType()                        { return resourceType; }
    public void   setResourceType(String resourceType)     { this.resourceType = resourceType; }

    public String getIssueKey()                    { return issueKey; }
    public void   setIssueKey(String issueKey)     { this.issueKey = issueKey; }

    public String getLinkType()                    { return linkType; }
    public void   setLinkType(String linkType)     { this.linkType = linkType; }

    public long getCreated()               { return created; }
    public void setCreated(long created)   { this.created = created; }

    /** Convenience: return the remote URI as a java.net.URI. */
    public URI toURI() { return URI.create(remoteUri); }

    @Override
    public String toString() {
        return "OslcLink{issueKey='" + issueKey + "', remoteUri='" + remoteUri
                + "', linkType='" + linkType + "'}";
    }
}

package com.example.oslc.service;

import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.example.oslc.util.OslcConstants;
import com.example.oslc.util.OslcUrlBuilder;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Collection;

/**
 * Builds OSLC Service Provider Catalog and individual Service Provider
 * RDF graphs from Jira projects.
 *
 * One ServiceProvider per Jira project; a single Catalog lists them all.
 */
@Named
public class OslcServiceProviderService {

    private final ProjectManager projectManager;
    private final OslcUrlBuilder urls;

    @Inject
    public OslcServiceProviderService(
            @ComponentImport ProjectManager projectManager,
            OslcUrlBuilder urls) {
        this.projectManager = projectManager;
        this.urls = urls;
    }

    // -----------------------------------------------------------------------
    // Catalog
    // -----------------------------------------------------------------------

    /**
     * Returns an RDF Model representing the top-level OSLC Service Provider
     * Catalog containing one entry per Jira project visible to the caller.
     */
    public Model buildCatalog() {
        Model model = ModelFactory.createDefaultModel();
        addPrefixes(model);

        Resource catalog = model.createResource(urls.catalogUrl())
                .addProperty(rdf(model, "type"),
                        model.createResource(OslcConstants.TYPE_SERVICE_PROVIDER_CATALOG))
                .addProperty(dc(model, "title"), "Jira OSLC Service Provider Catalog")
                .addProperty(dc(model, "description"),
                        "OSLC 2.0 Service Provider Catalog exposing all Jira projects.");

        Collection<Project> projects = projectManager.getProjects();
        for (Project project : projects) {
            Resource sp = model.createResource(urls.serviceProviderUrl(project.getKey()));
            catalog.addProperty(
                    model.createProperty(OslcConstants.OSLC_CORE_NS, "serviceProvider"), sp);
        }

        return model;
    }

    // -----------------------------------------------------------------------
    // Single ServiceProvider
    // -----------------------------------------------------------------------

    /**
     * Returns an RDF Model for one OSLC ServiceProvider (one Jira project).
     * Declares:
     *   – a CreationFactory  (POST to create issues)
     *   – a QueryCapability  (GET with oslc.where / oslc.select)
     *   – a Selection Dialog (UI delegate)
     */
    public Model buildServiceProvider(String projectKey) {
        Project project = projectManager.getProjectByCurrentKey(projectKey);
        if (project == null) return null;

        Model model = ModelFactory.createDefaultModel();
        addPrefixes(model);

        Resource sp = model.createResource(urls.serviceProviderUrl(projectKey))
                .addProperty(rdf(model, "type"),
                        model.createResource(OslcConstants.TYPE_SERVICE_PROVIDER))
                .addProperty(dc(model, "title"), project.getName())
                .addProperty(dc(model, "description"),
                        "OSLC Service Provider for Jira project " + projectKey)
                .addProperty(dc(model, "identifier"), projectKey);

        // ---- Service ----
        Resource service = model.createResource()
                .addProperty(rdf(model, "type"),
                        model.createResource(OslcConstants.TYPE_SERVICE))
                .addProperty(dc(model, "title"), "Change Management");

        // -- CreationFactory --
        Resource factory = model.createResource()
                .addProperty(rdf(model, "type"),
                        model.createResource(OslcConstants.TYPE_CREATION_FACTORY))
                .addProperty(dc(model, "title"), "Create Change Request")
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "creation"),
                        model.createResource(urls.changeRequestsUrl(projectKey)))
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "resourceShape"),
                        model.createResource(urls.resourceShapeUrl()))
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "resourceType"),
                        model.createResource(OslcConstants.TYPE_CHANGE_REQUEST));

        // -- QueryCapability --
        Resource query = model.createResource()
                .addProperty(rdf(model, "type"),
                        model.createResource(OslcConstants.TYPE_QUERY_CAPABILITY))
                .addProperty(dc(model, "title"), "Query Change Requests")
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "queryBase"),
                        model.createResource(urls.queryUrl(projectKey)))
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "resourceShape"),
                        model.createResource(urls.resourceShapeUrl()))
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "resourceType"),
                        model.createResource(OslcConstants.TYPE_CHANGE_REQUEST));

        // -- SelectionDialog --
        Resource dialog = model.createResource()
                .addProperty(rdf(model, "type"),
                        model.createResource(OslcConstants.TYPE_DIALOG))
                .addProperty(dc(model, "title"), "Select Jira Issue")
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "dialog"),
                        model.createResource(urls.selectionDialogUrl(projectKey)))
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "hintWidth"), "600px")
                .addProperty(
                        model.createProperty(OslcConstants.OSLC_CORE_NS, "hintHeight"), "500px");

        service.addProperty(
                model.createProperty(OslcConstants.OSLC_CORE_NS, "creationFactory"), factory);
        service.addProperty(
                model.createProperty(OslcConstants.OSLC_CORE_NS, "queryCapability"), query);
        service.addProperty(
                model.createProperty(OslcConstants.OSLC_CORE_NS, "selectionDialog"), dialog);

        sp.addProperty(
                model.createProperty(OslcConstants.OSLC_CORE_NS, "service"), service);

        return model;
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------
    private void addPrefixes(Model model) {
        model.setNsPrefix("oslc",    OslcConstants.OSLC_CORE_NS);
        model.setNsPrefix("oslc_cm", OslcConstants.OSLC_CM_NS);
        model.setNsPrefix("dcterms", OslcConstants.DCTERMS_NS);
        model.setNsPrefix("rdf",     OslcConstants.RDF_NS);
        model.setNsPrefix("rdfs",    OslcConstants.RDFS_NS);
    }

    private org.apache.jena.rdf.model.Property rdf(Model model, String local) {
        return model.createProperty(OslcConstants.RDF_NS, local);
    }

    private org.apache.jena.rdf.model.Property dc(Model model, String local) {
        return model.createProperty(OslcConstants.DCTERMS_NS, local);
    }
}

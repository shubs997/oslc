package com.example.oslc.service;

import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.ApplicationProperties;
import com.atlassian.sal.api.UrlMode;
import com.example.oslc.model.OslcChangeRequest;
import com.example.oslc.util.OslcConstants;
import com.example.oslc.util.OslcUrlBuilder;

import javax.inject.Inject;
import javax.inject.Named;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Converts Jira {@link Issue} objects into {@link OslcChangeRequest} objects
 * and handles GET/list/create operations at the OSLC CM layer.
 */
@Named
public class OslcChangeRequestService {

    private final IssueManager issueManager;
    private final ProjectManager projectManager;
    private final ApplicationProperties applicationProperties;
    private final OslcUrlBuilder urls;

    @Inject
    public OslcChangeRequestService(
            @ComponentImport IssueManager issueManager,
            @ComponentImport ProjectManager projectManager,
            @ComponentImport ApplicationProperties applicationProperties,
            OslcUrlBuilder urls) {
        this.issueManager = issueManager;
        this.projectManager = projectManager;
        this.applicationProperties = applicationProperties;
        this.urls = urls;
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Returns all issues for a project as OSLC ChangeRequest objects.
     */
    public List<OslcChangeRequest> getChangeRequestsForProject(String projectKey) {
        Project project = projectManager.getProjectByCurrentKey(projectKey);
        if (project == null) return List.of();

        Collection<Long> issueIds = issueManager.getIssueIdsForProject(project.getId());
        List<OslcChangeRequest> result = new ArrayList<>();
        for (Long id : issueIds) {
            Issue issue = issueManager.getIssueObject(id);
            if (issue != null) {
                result.add(toChangeRequest(issue, projectKey));
            }
        }
        return result;
    }

    /**
     * Returns a single issue as an OSLC ChangeRequest, or null if not found.
     */
    public OslcChangeRequest getChangeRequest(String projectKey, String issueKey) {
        Issue issue = issueManager.getIssueByCurrentKey(issueKey);
        if (issue == null) return null;
        return toChangeRequest(issue, projectKey);
    }

    // -----------------------------------------------------------------------
    // Mapping
    // -----------------------------------------------------------------------

    public OslcChangeRequest toChangeRequest(Issue issue, String projectKey) {
        URI about = URI.create(urls.changeRequestUrl(projectKey, issue.getKey()));
        OslcChangeRequest cr = new OslcChangeRequest(about);

        cr.setTitle(issue.getSummary());
        cr.setDescription(issue.getDescription());
        cr.setIdentifier(issue.getKey());
        cr.setShortTitle(issue.getKey() + ": " + truncate(issue.getSummary(), 60));

        // Timestamps
        if (issue.getCreated() != null) cr.setCreated(issue.getCreated());
        if (issue.getUpdated() != null) cr.setModified(issue.getUpdated());

        // Creator
        ApplicationUser reporter = issue.getReporter();
        if (reporter != null) {
            cr.setCreator(URI.create(
                    applicationProperties.getBaseUrl(UrlMode.ABSOLUTE)
                            + "/rest/api/2/user?accountId=" + reporter.getKey()));
        }

        // Assignee → contributor
        ApplicationUser assignee = issue.getAssignee();
        if (assignee != null) {
            cr.setContributor(URI.create(
                    applicationProperties.getBaseUrl(UrlMode.ABSOLUTE)
                            + "/rest/api/2/user?accountId=" + assignee.getKey()));
        }

        // Status flags
        String statusName = issue.getStatus() != null
                ? issue.getStatus().getName().toLowerCase() : "";
        cr.setClosed(statusName.contains("closed") || statusName.contains("done")
                || statusName.contains("resolved"));
        cr.setInProgress(statusName.contains("progress") || statusName.contains("review"));
        cr.setFixed(statusName.contains("fixed") || statusName.contains("resolved"));
        cr.setStatus(issue.getStatus() != null ? issue.getStatus().getName() : "");

        // Priority
        if (issue.getPriority() != null) {
            cr.setPriority(issue.getPriority().getName());
        }

        // Issue type
        if (issue.getIssueType() != null) {
            cr.setType(issue.getIssueType().getName());
        }

        // Browse URL as dcterms:subject
        cr.setSubject(URI.create(
                applicationProperties.getBaseUrl(UrlMode.ABSOLUTE)
                        + "/browse/" + issue.getKey()));

        // Service provider back-link
        cr.setServiceProvider(URI.create(urls.serviceProviderUrl(projectKey)));

        return cr;
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------
    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}

package com.example.oslc.service;

import com.atlassian.sal.api.pluginsettings.PluginSettings;
import com.atlassian.sal.api.pluginsettings.PluginSettingsFactory;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.example.oslc.model.OslcLink;
import com.example.oslc.util.OslcConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

// Minimal JSON serialization without external deps (uses simple manual approach;
// swap for Jackson if you add it to the POM)
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Stores and retrieves OSLC outgoing links for Jira issues using
 * Atlassian SAL PluginSettings (cluster-safe key-value store).
 *
 * Storage layout:
 *   key  → "com.example.oslc.links.<issueKey>"
 *   value → JSON array string: [{"remoteUri":"…","label":"…","resourceType":"…","linkType":"…","created":…}, …]
 */
@Named
public class OslcLinkService {

    private static final Logger log = LoggerFactory.getLogger(OslcLinkService.class);

    private final PluginSettings settings;

    @Inject
    public OslcLinkService(@ComponentImport PluginSettingsFactory pluginSettingsFactory) {
        this.settings = pluginSettingsFactory.createGlobalSettings();
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /** Returns all OSLC links stored for a given Jira issue key. */
    public List<OslcLink> getLinksForIssue(String issueKey) {
        String raw = (String) settings.get(settingsKey(issueKey));
        if (raw == null || raw.isBlank()) return new ArrayList<>();
        return deserialize(issueKey, raw);
    }

    /** Adds a new OSLC link to the given issue. Idempotent by remoteUri. */
    public void addLink(OslcLink link) {
        List<OslcLink> links = getLinksForIssue(link.getIssueKey());
        // Remove existing link to same URI before re-adding (upsert)
        links.removeIf(l -> l.getRemoteUri().equals(link.getRemoteUri()));
        links.add(link);
        persist(link.getIssueKey(), links);
        log.info("OSLC link added: issue={} → {}", link.getIssueKey(), link.getRemoteUri());
    }

    /** Removes the link with the given remoteUri from the issue. */
    public boolean removeLink(String issueKey, String remoteUri) {
        List<OslcLink> links = getLinksForIssue(issueKey);
        boolean removed = links.removeIf(l -> l.getRemoteUri().equals(remoteUri));
        if (removed) {
            persist(issueKey, links);
            log.info("OSLC link removed: issue={} → {}", issueKey, remoteUri);
        }
        return removed;
    }

    /** Removes all links for an issue (e.g. on issue deletion). */
    public void removeAllLinks(String issueKey) {
        settings.remove(settingsKey(issueKey));
    }

    // -----------------------------------------------------------------------
    // Serialization helpers
    // -----------------------------------------------------------------------
    private String settingsKey(String issueKey) {
        return OslcConstants.SETTINGS_LINKS_PREFIX + issueKey;
    }

    private void persist(String issueKey, List<OslcLink> links) {
        settings.put(settingsKey(issueKey), serialize(links));
    }

    private String serialize(List<OslcLink> links) {
        JSONArray arr = new JSONArray();
        for (OslcLink l : links) {
            JSONObject obj = new JSONObject();
            obj.put("remoteUri",    l.getRemoteUri());
            obj.put("label",        l.getLabel()        != null ? l.getLabel()        : "");
            obj.put("resourceType", l.getResourceType() != null ? l.getResourceType() : "");
            obj.put("linkType",     l.getLinkType()     != null ? l.getLinkType()     : "");
            obj.put("created",      l.getCreated());
            arr.put(obj);
        }
        return arr.toString();
    }

    private List<OslcLink> deserialize(String issueKey, String json) {
        List<OslcLink> result = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                OslcLink link = new OslcLink();
                link.setIssueKey(issueKey);
                link.setRemoteUri(obj.optString("remoteUri"));
                link.setLabel(obj.optString("label"));
                link.setResourceType(obj.optString("resourceType"));
                link.setLinkType(obj.optString("linkType"));
                link.setCreated(obj.optLong("created", System.currentTimeMillis()));
                result.add(link);
            }
        } catch (Exception e) {
            log.error("Failed to deserialize OSLC links for issue {}: {}", issueKey, e.getMessage());
        }
        return result;
    }
}

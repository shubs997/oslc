package com.example.oslc.rest;

import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.example.oslc.service.OslcServiceProviderService;
import com.example.oslc.util.OslcConstants;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.riot.RDFFormat;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.io.StringWriter;

/**
 * REST resource exposing:
 *
 *   GET /rest/oslc/1.0/catalog
 *       → OSLC Service Provider Catalog (all Jira projects)
 *
 *   GET /rest/oslc/1.0/serviceProviders/{projectKey}
 *       → OSLC Service Provider for a single project
 *
 * Supports content-negotiation:  application/rdf+xml (default), text/turtle, application/ld+json
 */
@Path("/")
@Named
public class CatalogResource {

    private final OslcServiceProviderService catalogService;

    @Inject
    public CatalogResource(OslcServiceProviderService catalogService) {
        this.catalogService = catalogService;
    }

    // -----------------------------------------------------------------------
    // Catalog
    // -----------------------------------------------------------------------

    @GET
    @Path("/catalog")
    @Produces({OslcConstants.CT_RDF_XML, OslcConstants.CT_TURTLE,
               OslcConstants.CT_JSON_LD, MediaType.TEXT_HTML})
    @AnonymousAllowed
    public Response getCatalog(@Context HttpHeaders headers) {
        Model model = catalogService.buildCatalog();
        return serializeModel(model, negotiateFormat(headers));
    }

    // -----------------------------------------------------------------------
    // Single ServiceProvider
    // -----------------------------------------------------------------------

    @GET
    @Path("/serviceProviders/{projectKey}")
    @Produces({OslcConstants.CT_RDF_XML, OslcConstants.CT_TURTLE,
               OslcConstants.CT_JSON_LD, MediaType.TEXT_HTML})
    @AnonymousAllowed
    public Response getServiceProvider(
            @PathParam("projectKey") String projectKey,
            @Context HttpHeaders headers) {

        Model model = catalogService.buildServiceProvider(projectKey);
        if (model == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("Project not found: " + projectKey).build();
        }
        return serializeModel(model, negotiateFormat(headers));
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private Response serializeModel(Model model, RDFFormat format) {
        StringWriter sw = new StringWriter();
        RDFDataMgr.write(sw, model, format);
        String contentType = rdfFormatToContentType(format);
        return Response.ok(sw.toString())
                .header("OSLC-Core-Version", "2.0")
                .header(HttpHeaders.CONTENT_TYPE, contentType)
                .build();
    }

    private RDFFormat negotiateFormat(HttpHeaders headers) {
        for (MediaType mt : headers.getAcceptableMediaTypes()) {
            String type = mt.getType() + "/" + mt.getSubtype();
            if (OslcConstants.CT_TURTLE.equals(type))  return RDFFormat.TURTLE_PRETTY;
            if (OslcConstants.CT_JSON_LD.equals(type)) return RDFFormat.JSONLD_PRETTY;
        }
        return RDFFormat.RDFXML_PRETTY;
    }

    private String rdfFormatToContentType(RDFFormat fmt) {
        if (fmt == RDFFormat.TURTLE_PRETTY) return OslcConstants.CT_TURTLE;
        if (fmt == RDFFormat.JSONLD_PRETTY)  return OslcConstants.CT_JSON_LD;
        return OslcConstants.CT_RDF_XML;
    }
}

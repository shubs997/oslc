package com.example.oslc.service;

import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.issue.search.SearchResults;
import com.atlassian.jira.jql.builder.JqlQueryBuilder;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.example.oslc.model.OslcChangeRequest;
import com.atlassian.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Handles OSLC Query (oslc.where / oslc.select / oslc.paging).
 *
 * Supported oslc.where operators:
 *   dcterms:title="…"        → summary contains
 *   oslc_cm:status="…"       → status name equals
 *   dcterms:type="…"         → issue type equals
 *   oslc_cm:priority="…"     → priority equals
 *
 * All operators are translated to JQL and executed via Jira's SearchService.
 */
@Named
public class OslcQueryService {

    private static final Logger log = LoggerFactory.getLogger(OslcQueryService.class);

    private static final int DEFAULT_PAGE_SIZE = 50;

    private final SearchService searchService;
    private final OslcChangeRequestService changeRequestService;

    @Inject
    public OslcQueryService(
            @ComponentImport SearchService searchService,
            OslcChangeRequestService changeRequestService) {
        this.searchService = searchService;
        this.changeRequestService = changeRequestService;
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Executes an OSLC query for the given project.
     *
     * @param projectKey   Jira project key
     * @param oslcWhere    raw oslc.where string (may be null/empty)
     * @param oslcSelect   raw oslc.select string (ignored – all props returned)
     * @param pageSize     oslc.pageSize (0 = use default)
     * @param startIndex   oslc.paging start index
     * @param currentUser  authenticated Jira user
     */
    public OslcQueryResult query(
            String projectKey,
            String oslcWhere,
            String oslcSelect,
            int pageSize,
            int startIndex,
            ApplicationUser currentUser) {

        int limit = pageSize > 0 ? pageSize : DEFAULT_PAGE_SIZE;
        Query jql = buildJql(projectKey, oslcWhere);

        List<OslcChangeRequest> items = new ArrayList<>();
        int total = 0;

        try {
            PagerFilter<Issue> pager = PagerFilter.newPageAlignedFilter(startIndex, limit);
            SearchResults<Issue> results = searchService.search(currentUser, jql, pager);
            total = (int) results.getTotal();
            for (Issue issue : results.getResults()) {
                items.add(changeRequestService.toChangeRequest(issue, projectKey));
            }
        } catch (SearchException e) {
            log.error("OSLC query failed for project {}: {}", projectKey, e.getMessage(), e);
        }

        return new OslcQueryResult(items, total, startIndex, limit);
    }

    // -----------------------------------------------------------------------
    // JQL builder
    // -----------------------------------------------------------------------

    /**
     * Translates a simplified oslc.where string into a Jira JQL query.
     *
     * OSLC where grammar subset supported:
     *   term        ::= compoundTerm ("and" compoundTerm)*
     *   compoundTerm::= property operator value
     *   operator    ::= "=" | "!=" | "in" | "!in"
     *   value       ::= '"' string '"' | listValue
     */
    private Query buildJql(String projectKey, String oslcWhere) {
        JqlQueryBuilder builder = JqlQueryBuilder.newBuilder();
        builder.where().project(projectKey);

        if (oslcWhere != null && !oslcWhere.isBlank()) {
            // Parse top-level AND clauses
            String[] clauses = oslcWhere.split("(?i)\\s+and\\s+");
            for (String clause : clauses) {
                applyClause(builder, clause.trim());
            }
        }

        return builder.buildQuery();
    }

    private void applyClause(JqlQueryBuilder builder, String clause) {
        // dcterms:title="value"
        if (matchPrefix(clause, "dcterms:title")) {
            String val = extractStringValue(clause);
            if (val != null) builder.where().and().summary(val);

        // oslc_cm:status="value"
        } else if (matchPrefix(clause, "oslc_cm:status")) {
            String val = extractStringValue(clause);
            if (val != null) builder.where().and().status(val);

        // dcterms:type="value"
        } else if (matchPrefix(clause, "dcterms:type")) {
            String val = extractStringValue(clause);
            if (val != null) builder.where().and().issueType(val);

        // oslc_cm:priority="value"
        } else if (matchPrefix(clause, "oslc_cm:priority")) {
            String val = extractStringValue(clause);
            if (val != null) builder.where().and().priority(val);

        } else {
            log.debug("Unsupported oslc.where clause ignored: {}", clause);
        }
    }

    private boolean matchPrefix(String clause, String prefix) {
        return clause.startsWith(prefix);
    }

    /** Extracts the quoted string value from  property="value"  */
    private String extractStringValue(String clause) {
        int start = clause.indexOf('"');
        int end   = clause.lastIndexOf('"');
        if (start >= 0 && end > start) {
            return clause.substring(start + 1, end);
        }
        return null;
    }

    // -----------------------------------------------------------------------
    // Result wrapper
    // -----------------------------------------------------------------------

    public static class OslcQueryResult {
        public final List<OslcChangeRequest> items;
        public final int total;
        public final int startIndex;
        public final int pageSize;

        public OslcQueryResult(List<OslcChangeRequest> items, int total,
                               int startIndex, int pageSize) {
            this.items      = items;
            this.total      = total;
            this.startIndex = startIndex;
            this.pageSize   = pageSize;
        }

        public boolean hasMore() {
            return startIndex + items.size() < total;
        }

        public int nextPage() {
            return startIndex + pageSize;
        }
    }
}

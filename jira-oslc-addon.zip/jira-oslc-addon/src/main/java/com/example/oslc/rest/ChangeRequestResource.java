package com.example.oslc.rest;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.example.oslc.model.OslcChangeRequest;
import com.example.oslc.service.OslcChangeRequestService;
import com.example.oslc.service.OslcQueryService;
import com.example.oslc.util.OslcConstants;
import com.example.oslc.util.OslcUrlBuilder;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.riot.RDFFormat;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.io.StringWriter;
import java.net.URI;
import java.util.List;

/**
 * OSLC Change Management endpoints.
 *
 *   GET    /serviceProviders/{key}/resources/changeRequests          → list
 *   POST   /serviceProviders/{key}/resources/changeRequests          → create (stub)
 *   GET    /serviceProviders/{key}/resources/changeRequests/{issue}  → single
 *   PUT    /serviceProviders/{key}/resources/changeRequests/{issue}  → update (stub)
 *   GET    /serviceProviders/{key}/resources/changeRequests/{issue}/compact → OSLC Compact
 *   GET    /serviceProviders/{key}/resources/query                   → OSLC Query
 */
@Path("/serviceProviders/{projectKey}/resources")
@Named
public class ChangeRequestResource {

    private final OslcChangeRequestService changeRequestService;
    private final OslcQueryService queryService;
    private final OslcUrlBuilder urls;

    @Inject
    public ChangeRequestResource(
            OslcChangeRequestService changeRequestService,
            OslcQueryService queryService,
            OslcUrlBuilder urls) {
        this.changeRequestService = changeRequestService;
        this.queryService         = queryService;
        this.urls                 = urls;
    }

    // -----------------------------------------------------------------------
    // List Change Requests
    // -----------------------------------------------------------------------

    @GET
    @Path("/changeRequests")
    @Produces({OslcConstants.CT_RDF_XML, OslcConstants.CT_TURTLE, OslcConstants.CT_JSON_LD})
    @AnonymousAllowed
    public Response listChangeRequests(
            @PathParam("projectKey") String projectKey,
            @Context HttpHeaders headers) {

        List<OslcChangeRequest> crs = changeRequestService.getChangeRequestsForProject(projectKey);
        Model model = buildCollectionModel(projectKey, crs);
        return rdfResponse(model, headers);
    }

    // -----------------------------------------------------------------------
    // Get single Change Request
    // -----------------------------------------------------------------------

    @GET
    @Path("/changeRequests/{issueKey}")
    @Produces({OslcConstants.CT_RDF_XML, OslcConstants.CT_TURTLE,
               OslcConstants.CT_JSON_LD, MediaType.TEXT_HTML})
    @AnonymousAllowed
    public Response getChangeRequest(
            @PathParam("projectKey") String projectKey,
            @PathParam("issueKey")   String issueKey,
            @Context HttpHeaders headers) {

        OslcChangeRequest cr = changeRequestService.getChangeRequest(projectKey, issueKey);
        if (cr == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("Issue not found: " + issueKey).build();
        }

        // Check Accept for OSLC Compact (hover preview)
        for (MediaType mt : headers.getAcceptableMediaTypes()) {
            if (OslcConstants.CT_OSLC_COMPACT.equals(mt.getType() + "/" + mt.getSubtype())) {
                return compactResponse(projectKey, cr);
            }
        }

        Model model = changeRequestToModel(cr);
        return rdfResponse(model, headers);
    }

    // -----------------------------------------------------------------------
    // OSLC Compact (hover preview descriptor)
    // -----------------------------------------------------------------------

    @GET
    @Path("/changeRequests/{issueKey}/compact")
    @Produces(OslcConstants.CT_OSLC_COMPACT)
    @AnonymousAllowed
    public Response getCompact(
            @PathParam("projectKey") String projectKey,
            @PathParam("issueKey")   String issueKey) {

        OslcChangeRequest cr = changeRequestService.getChangeRequest(projectKey, issueKey);
        if (cr == null) return Response.status(404).build();
        return compactResponse(projectKey, cr);
    }

    // -----------------------------------------------------------------------
    // OSLC Query
    // -----------------------------------------------------------------------

    @GET
    @Path("/query")
    @Produces({OslcConstants.CT_RDF_XML, OslcConstants.CT_TURTLE, OslcConstants.CT_JSON_LD})
    @AnonymousAllowed
    public Response query(
            @PathParam("projectKey")  String projectKey,
            @QueryParam("oslc.where") String oslcWhere,
            @QueryParam("oslc.select") String oslcSelect,
            @QueryParam("oslc.pageSize") @DefaultValue("50") int pageSize,
            @QueryParam("oslc.paging") @DefaultValue("false") boolean paging,
            @QueryParam("startIndex") @DefaultValue("0") int startIndex,
            @Context HttpHeaders headers) {

        ApplicationUser user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser();

        OslcQueryService.OslcQueryResult result =
                queryService.query(projectKey, oslcWhere, oslcSelect,
                        pageSize, startIndex, user);

        Model model = buildCollectionModel(projectKey, result.items);
        Response.ResponseBuilder rb = Response.ok(serializeModel(model, negotiateFormat(headers)))
                .header("OSLC-Core-Version", "2.0")
                .header(HttpHeaders.CONTENT_TYPE, OslcConstants.CT_RDF_XML);

        // OSLC paging headers
        if (paging && result.hasMore()) {
            String nextUrl = urls.queryUrl(projectKey)
                    + "?startIndex=" + result.nextPage()
                    + "&oslc.pageSize=" + pageSize;
            rb.header("Link", "<" + nextUrl + ">; rel=\"next\"");
        }
        rb.header("X-OSLC-TotalCount", result.total);

        return rb.build();
    }

    // -----------------------------------------------------------------------
    // POST – create (stub; full impl would parse RDF body and create Jira issue)
    // -----------------------------------------------------------------------

    @POST
    @Path("/changeRequests")
    @Consumes({OslcConstants.CT_RDF_XML, OslcConstants.CT_TURTLE})
    @Produces({OslcConstants.CT_RDF_XML})
    public Response createChangeRequest(
            @PathParam("projectKey") String projectKey,
            String body) {
        // TODO: parse incoming RDF, map to Jira CreateIssueRequest, create issue
        return Response.status(Response.Status.NOT_IMPLEMENTED)
                .entity("Creation via OSLC not yet implemented").build();
    }

    // -----------------------------------------------------------------------
    // Compact / Preview XML builder
    // -----------------------------------------------------------------------

    private Response compactResponse(String projectKey, OslcChangeRequest cr) {
        String issueKey = cr.getIdentifier();
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<rdf:RDF xmlns:rdf=\"" + OslcConstants.RDF_NS + "\"\n"
                + "         xmlns:oslc=\"" + OslcConstants.OSLC_CORE_NS + "\"\n"
                + "         xmlns:dcterms=\"" + OslcConstants.DCTERMS_NS + "\">\n"
                + "  <oslc:Compact rdf:about=\""
                +       urls.changeRequestUrl(projectKey, issueKey) + "\">\n"
                + "    <dcterms:title>" + escapeXml(cr.getShortTitle()) + "</dcterms:title>\n"
                + "    <oslc:shortTitle>" + escapeXml(issueKey) + "</oslc:shortTitle>\n"
                + "    <oslc:smallPreview>\n"
                + "      <oslc:Preview>\n"
                + "        <oslc:document rdf:resource=\""
                +           urls.previewUrl(projectKey, issueKey) + "\"/>\n"
                + "        <oslc:hintWidth>400px</oslc:hintWidth>\n"
                + "        <oslc:hintHeight>120px</oslc:hintHeight>\n"
                + "      </oslc:Preview>\n"
                + "    </oslc:smallPreview>\n"
                + "    <oslc:largePreview>\n"
                + "      <oslc:Preview>\n"
                + "        <oslc:document rdf:resource=\""
                +           urls.previewUrl(projectKey, issueKey) + "?size=large\"/>\n"
                + "        <oslc:hintWidth>600px</oslc:hintWidth>\n"
                + "        <oslc:hintHeight>400px</oslc:hintHeight>\n"
                + "      </oslc:Preview>\n"
                + "    </oslc:largePreview>\n"
                + "  </oslc:Compact>\n"
                + "</rdf:RDF>";

        return Response.ok(xml)
                .header("Content-Type", OslcConstants.CT_OSLC_COMPACT)
                .header("OSLC-Core-Version", "2.0")
                .build();
    }

    // -----------------------------------------------------------------------
    // RDF helpers
    // -----------------------------------------------------------------------

    private Model changeRequestToModel(OslcChangeRequest cr) {
        Model model = ModelFactory.createDefaultModel();
        addPrefixes(model);
        Resource r = model.createResource(cr.getAbout().toString());
        r.addProperty(model.createProperty(OslcConstants.RDF_NS, "type"),
                model.createResource(OslcConstants.TYPE_CHANGE_REQUEST));
        if (cr.getTitle() != null)
            r.addProperty(model.createProperty(OslcConstants.DCTERMS_NS, "title"), cr.getTitle());
        if (cr.getDescription() != null)
            r.addProperty(model.createProperty(OslcConstants.DCTERMS_NS, "description"), cr.getDescription());
        if (cr.getIdentifier() != null)
            r.addProperty(model.createProperty(OslcConstants.DCTERMS_NS, "identifier"), cr.getIdentifier());
        if (cr.getStatus() != null)
            r.addProperty(model.createProperty(OslcConstants.OSLC_CM_NS, "status"), cr.getStatus());
        if (cr.getPriority() != null)
            r.addProperty(model.createProperty(OslcConstants.OSLC_CM_NS, "priority"), cr.getPriority());
        if (cr.getType() != null)
            r.addProperty(model.createProperty(OslcConstants.DCTERMS_NS, "type"), cr.getType());
        if (cr.getServiceProvider() != null)
            r.addProperty(model.createProperty(OslcConstants.OSLC_CORE_NS, "serviceProvider"),
                    model.createResource(cr.getServiceProvider().toString()));
        if (cr.getShortTitle() != null)
            r.addProperty(model.createProperty(OslcConstants.OSLC_CORE_NS, "shortTitle"), cr.getShortTitle());
        if (cr.getSubject() != null)
            r.addProperty(model.createProperty(OslcConstants.DCTERMS_NS, "subject"),
                    model.createResource(cr.getSubject().toString()));
        r.addProperty(model.createProperty(OslcConstants.OSLC_CM_NS, "closed"),
                model.createTypedLiteral(cr.isClosed()));
        r.addProperty(model.createProperty(OslcConstants.OSLC_CM_NS, "inprogress"),
                model.createTypedLiteral(cr.isInProgress()));
        return model;
    }

    private Model buildCollectionModel(String projectKey, List<OslcChangeRequest> crs) {
        Model model = ModelFactory.createDefaultModel();
        addPrefixes(model);
        for (OslcChangeRequest cr : crs) {
            Resource r = model.createResource(cr.getAbout().toString());
            r.addProperty(model.createProperty(OslcConstants.RDF_NS, "type"),
                    model.createResource(OslcConstants.TYPE_CHANGE_REQUEST));
            if (cr.getTitle() != null)
                r.addProperty(model.createProperty(OslcConstants.DCTERMS_NS, "title"), cr.getTitle());
            if (cr.getIdentifier() != null)
                r.addProperty(model.createProperty(OslcConstants.DCTERMS_NS, "identifier"), cr.getIdentifier());
            if (cr.getStatus() != null)
                r.addProperty(model.createProperty(OslcConstants.OSLC_CM_NS, "status"), cr.getStatus());
        }
        return model;
    }

    private void addPrefixes(Model model) {
        model.setNsPrefix("oslc",    OslcConstants.OSLC_CORE_NS);
        model.setNsPrefix("oslc_cm", OslcConstants.OSLC_CM_NS);
        model.setNsPrefix("dcterms", OslcConstants.DCTERMS_NS);
        model.setNsPrefix("rdf",     OslcConstants.RDF_NS);
    }

    private Response rdfResponse(Model model, HttpHeaders headers) {
        RDFFormat fmt = negotiateFormat(headers);
        String ct  = rdfFormatToContentType(fmt);
        return Response.ok(serializeModel(model, fmt))
                .header("Content-Type", ct)
                .header("OSLC-Core-Version", "2.0")
                .build();
    }

    private String serializeModel(Model model, RDFFormat format) {
        StringWriter sw = new StringWriter();
        RDFDataMgr.write(sw, model, format);
        return sw.toString();
    }

    private RDFFormat negotiateFormat(HttpHeaders headers) {
        for (MediaType mt : headers.getAcceptableMediaTypes()) {
            String t = mt.getType() + "/" + mt.getSubtype();
            if (OslcConstants.CT_TURTLE.equals(t))  return RDFFormat.TURTLE_PRETTY;
            if (OslcConstants.CT_JSON_LD.equals(t)) return RDFFormat.JSONLD_PRETTY;
        }
        return RDFFormat.RDFXML_PRETTY;
    }

    private String rdfFormatToContentType(RDFFormat fmt) {
        if (fmt == RDFFormat.TURTLE_PRETTY) return OslcConstants.CT_TURTLE;
        if (fmt == RDFFormat.JSONLD_PRETTY)  return OslcConstants.CT_JSON_LD;
        return OslcConstants.CT_RDF_XML;
    }

    private String escapeXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }
}

package com.example.oslc.util;

import com.atlassian.sal.api.ApplicationProperties;
import com.atlassian.sal.api.UrlMode;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Centralised factory for all OSLC endpoint URLs.
 *
 * The base path mirrors the REST module declaration in atlassian-plugin.xml:
 *   path="/oslc" → {jiraBase}/rest/oslc/1.0/…
 */
@Named
public class OslcUrlBuilder {

    private final String base;   // e.g. "http://localhost:2990/jira/rest/oslc/1.0"

    @Inject
    public OslcUrlBuilder(ApplicationProperties applicationProperties) {
        this.base = applicationProperties.getBaseUrl(UrlMode.ABSOLUTE) + "/rest/oslc/1.0";
    }

    // Provided for tests without DI
    public OslcUrlBuilder(String jiraBaseUrl) {
        this.base = jiraBaseUrl + "/rest/oslc/1.0";
    }

    public String catalogUrl() {
        return base + "/catalog";
    }

    public String serviceProviderUrl(String projectKey) {
        return base + "/serviceProviders/" + projectKey;
    }

    public String changeRequestsUrl(String projectKey) {
        return base + "/serviceProviders/" + projectKey + "/resources/changeRequests";
    }

    public String changeRequestUrl(String projectKey, String issueKey) {
        return base + "/serviceProviders/" + projectKey + "/resources/changeRequests/" + issueKey;
    }

    public String queryUrl(String projectKey) {
        return base + "/serviceProviders/" + projectKey + "/resources/query";
    }

    public String compactUrl(String projectKey, String issueKey) {
        return base + "/serviceProviders/" + projectKey
                + "/resources/changeRequests/" + issueKey + "/compact";
    }

    public String resourceShapeUrl() {
        return base + "/resourceShapes/changeRequest";
    }

    /** URL served by the Servlet (not the REST module). */
    public String selectionDialogUrl(String projectKey) {
        return base.replace("/rest/oslc/1.0", "")
                + "/plugins/servlet/oslc/dialogs/selection?projectKey=" + projectKey;
    }

    /** Preview UI served by the Servlet. */
    public String previewUrl(String projectKey, String issueKey) {
        return base.replace("/rest/oslc/1.0", "")
                + "/plugins/servlet/oslc/preview/" + projectKey + "/" + issueKey;
    }
}
